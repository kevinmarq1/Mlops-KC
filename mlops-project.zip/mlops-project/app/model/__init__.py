import mlflow.pyfunc

RUN_ID = "b87760e168184c68b62ef5c994c011de"
MODEL_PATH = f"runs:/{RUN_ID}/modelo_rf_v1_test"

# Cargar modelo
model = mlflow.pyfunc.load_model(MODEL_PATH)
__all__ = ["model"]
