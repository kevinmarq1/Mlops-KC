from transformers import pipeline

# Inicializar los pipelines de Hugging Face solo una vez
summarizer = pipeline("summarization", model="sshleifer/distilbart-cnn-12-6")
sentiment_analyzer = pipeline("sentiment-analysis")

def summarize_text(text: str) -> str:
    """
    Resume el texto utilizando un modelo preentrenado de Hugging Face.
    """
    try:
        summary = summarizer(text, max_length=60, min_length=20, do_sample=False)
        return summary[0]['summary_text']
    except Exception as e:
        return f"❌ Error al resumir el texto: {e}"

def analyze_sentiment(text: str) -> str:
    """
    Analiza el sentimiento del texto (positivo, negativo, neutral).
    """
    try:
        result = sentiment_analyzer(text)
        label = result[0]['label']
        score = result[0]['score']
        return f"Sentimiento: {label} (confianza: {score:.2f})"
    except Exception as e:
        return f"❌ Error al analizar sentimiento: {e}"
