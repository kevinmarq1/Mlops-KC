import os
import mlflow.sklearn
import pandas as pd

# Ruta base al archivo actual
base_path = os.path.dirname(os.path.abspath(__file__))

# Ruta corregida al archivo run_id
run_id_path = os.path.join(base_path, "..", "..", "notebooks", "latest_run_id.txt")

# Función para cargar el modelo desde MLflow
def load_model():
    try:
        with open(run_id_path, "r") as f:
            run_id = f.read().strip()
        model_uri = f"runs:/{run_id}/model"
        model = mlflow.sklearn.load_model(model_uri)
        return model
    except Exception as e:
        raise RuntimeError(f"❌ No se pudo cargar el modelo desde MLflow: {e}")

# Cargar modelo una sola vez
model = load_model()

# Predicción con los datos del paciente
def predict_cancer(input_data: dict) -> str:
    try:
        # Mapea las claves de snake_case a los nombres reales usados en el modelo
        key_mapping = {
            "mean_radius": "mean radius",
            "mean_texture": "mean texture",
            "mean_perimeter": "mean perimeter",
            "mean_area": "mean area",
            "mean_smoothness": "mean smoothness",
            "mean_compactness": "mean compactness",
            "mean_concavity": "mean concavity",
            "mean_concave_points": "mean concave points",
            "mean_symmetry": "mean symmetry",
            "mean_fractal_dimension": "mean fractal dimension",
            "radius_error": "radius error",
            "texture_error": "texture error",
            "perimeter_error": "perimeter error",
            "area_error": "area error",
            "smoothness_error": "smoothness error",
            "compactness_error": "compactness error",
            "concavity_error": "concavity error",
            "concave_points_error": "concave points error",
            "symmetry_error": "symmetry error",
            "fractal_dimension_error": "fractal dimension error",
            "worst_radius": "worst radius",
            "worst_texture": "worst texture",
            "worst_perimeter": "worst perimeter",
            "worst_area": "worst area",
            "worst_smoothness": "worst smoothness",
            "worst_compactness": "worst compactness",
            "worst_concavity": "worst concavity",
            "worst_concave_points": "worst concave points",
            "worst_symmetry": "worst symmetry",
            "worst_fractal_dimension": "worst fractal dimension"
        }

        # Renombrar claves según el mapeo
        transformed_input = {key_mapping[k]: v for k, v in input_data.items() if k in key_mapping}
        input_df = pd.DataFrame([transformed_input])
        prediction = model.predict(input_df)[0]
        return "Maligno" if prediction == 1 else "Benigno"
    except Exception as e:
        raise RuntimeError(f"❌ Error al predecir: {e}")

# Obtener nombres de las características del modelo
def get_feature_names() -> list:
    try:
        return model.feature_names_in_.tolist()
    except Exception as e:
        raise RuntimeError(f"❌ No se pudieron obtener las características: {e}")
