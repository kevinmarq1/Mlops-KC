from fastapi import FastAPI
from app.schemas import PatientData, TextData
from app.utils.ml_utils import predict_cancer, get_feature_names
from app.utils.huggingface_utils import summarize_text, analyze_sentiment

app = FastAPI(
    title="🧠 API de Diagnóstico y NLP",
    description="Predice cáncer de mama y analiza texto con modelos de ML y HuggingFace",
    version="1.0.0"
)

@app.get("/", tags=["Sistema"])
def root():
    """
    Endpoint raíz para verificar que la API está activa.
    """
    return {"message": "🚀 API activa y funcionando correctamente."}

@app.get("/features", tags=["Modelo"])
def features():
    """
    Devuelve la lista de variables que necesita el modelo de cáncer.
    """
    return {"features": get_feature_names()}

@app.post("/predict", tags=["Modelo"])
def predict(data: PatientData):
    """
    Predice si un tumor es maligno o benigno a partir de los datos del paciente.
    """
    prediction = predict_cancer(data.dict())
    return {"predicción": prediction}

@app.post("/summarize", tags=["NLP"])
def summarize(data: TextData):
    """
    Resume un texto utilizando un modelo de Hugging Face.
    """
    resumen = summarize_text(data.text)
    return {"resumen": resumen}

@app.post("/sentiment", tags=["NLP"])
def sentiment(data: TextData):
    """
    Analiza el sentimiento de un texto.
    """
    resultado = analyze_sentiment(data.text)
    return {"sentimiento": resultado}
