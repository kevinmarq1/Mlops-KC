from pydantic import BaseModel
from typing import Optional, List


class PatientData(BaseModel):
    mean_radius: float
    mean_texture: float
    mean_perimeter: float
    mean_area: float
    mean_smoothness: float
    mean_compactness: float
    mean_concavity: float
    mean_concave_points: float
    mean_symmetry: float
    mean_fractal_dimension: float
    radius_error: float
    texture_error: float
    perimeter_error: float
    area_error: float
    smoothness_error: float
    compactness_error: float
    concavity_error: float
    concave_points_error: float
    symmetry_error: float
    fractal_dimension_error: float
    worst_radius: float
    worst_texture: float
    worst_perimeter: float
    worst_area: float
    worst_smoothness: float
    worst_compactness: float
    worst_concavity: float
    worst_concave_points: float
    worst_symmetry: float
    worst_fractal_dimension: float

    def to_model_input(self):
        return {
            "mean radius": self.mean_radius,
            "mean texture": self.mean_texture,
            "mean perimeter": self.mean_perimeter,
            "mean area": self.mean_area,
            "mean smoothness": self.mean_smoothness,
            "mean compactness": self.mean_compactness,
            "mean concavity": self.mean_concavity,
            "mean concave points": self.mean_concave_points,
            "mean symmetry": self.mean_symmetry,
            "mean fractal dimension": self.mean_fractal_dimension,
            "radius error": self.radius_error,
            "texture error": self.texture_error,
            "perimeter error": self.perimeter_error,
            "area error": self.area_error,
            "smoothness error": self.smoothness_error,
            "compactness error": self.compactness_error,
            "concavity error": self.concavity_error,
            "concave points error": self.concave_points_error,
            "symmetry error": self.symmetry_error,
            "fractal dimension error": self.fractal_dimension_error,
            "worst radius": self.worst_radius,
            "worst texture": self.worst_texture,
            "worst perimeter": self.worst_perimeter,
            "worst area": self.worst_area,
            "worst smoothness": self.worst_smoothness,
            "worst compactness": self.worst_compactness,
            "worst concavity": self.worst_concavity,
            "worst concave points": self.worst_concave_points,
            "worst symmetry": self.worst_symmetry,
            "worst fractal dimension": self.worst_fractal_dimension
        }


class TextData(BaseModel):
    text: str
